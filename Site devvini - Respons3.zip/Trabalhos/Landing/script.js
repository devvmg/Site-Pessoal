function popupEbook(){
    let x = document.forms["formularioEbook"]["ebookNombre"].value;
    let y = document.forms["formularioEbook"]["ebookApellido"].value;
    let z = document.forms["formularioEbook"]["ebookEmail"].value;
        if(x == "" || y == "" || z ==""){
            alert("¡Datos inválidos! Revisa los datos insertados en el formulario, ha faltado algun.");
    }else{
        alert("¡E-Book InboundCycle enviado a su E-mail!");
    }
}